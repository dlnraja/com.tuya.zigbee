'use strict';

const { ZigBeeDevice } = require('homey-zigbeedriver');

class SmartSwitch3gangHybridDevice extends ZigBeeDevice {

    async onNodeInit() {
        this.log('smart_switch_3gang_hybrid device initialized');

        // Register capabilities
                // Register on/off capability
        this.registerCapabilityListener('onoff', this.onCapabilityOnoff.bind(this));

        // Mark device as available
        await this.setAvailable();
    }

        async onCapabilityOnoff(value, opts) {
        this.log('onCapabilityOnoff:', value);
        
        try {
            if (value) {
                await this.zclNode.endpoints[1].clusters.onOff.setOn();
            } else {
                await this.zclNode.endpoints[1].clusters.onOff.setOff();
            }
            
            return Promise.resolve();
        } catch (error) {
            this.error('Error setting onoff:', error);
            return Promise.reject(error);
        }
    }

    async onDeleted() {
        this.log('smart_switch_3gang_hybrid device deleted');
    }

}

module.exports = SmartSwitch3gangHybridDevice;
