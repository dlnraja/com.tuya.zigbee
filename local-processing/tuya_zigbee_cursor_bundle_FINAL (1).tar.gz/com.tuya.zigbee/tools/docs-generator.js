// ✅ Cursor-Aware Script
// Description: Génère une documentation .md multi-langue à partir des drivers

const fs = require('fs');
const path = require('path');

const driversDir = './drivers';
const docsPath = './docs/driver-matrix.md';

const rows = ['| ID | Zigbee | Endpoints | Manufacturer | Model ID |', '|----|--------|-----------|--------------|-----------|'];

fs.readdirSync(driversDir).forEach(file => {
    if (file.endsWith('.driver.compose.json')) {
        const data = JSON.parse(fs.readFileSync(path.join(driversDir, file), 'utf8'));
        rows.push(`| ${data.id || '-'} | ${data.zigbee || '-'} | ${JSON.stringify(data.endpoints) || '-'} | ${data.manufacturerName || '-'} | ${data.modelId || '-'} |`);
    }
});

fs.writeFileSync(docsPath, rows.join('\n'));
console.log('✅ Documentation générée :', docsPath);
