const { Device } = require('homey');
 'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class switch_4_gang_metering extends ZigBeeDriver { } module.exports = switch_4_gang_metering; 


