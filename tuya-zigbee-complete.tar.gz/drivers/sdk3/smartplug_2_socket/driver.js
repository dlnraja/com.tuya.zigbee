const { Device } = require('homey');
 'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class smartplug_2_socket_driver extends ZigBeeDriver { } module.exports = smartplug_2_socket_driver; 


