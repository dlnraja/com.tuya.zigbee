const { Device } = require('homey');
 'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class socket_power_strip_four_three extends ZigBeeDriver { } module.exports = socket_power_strip_four_three; 


