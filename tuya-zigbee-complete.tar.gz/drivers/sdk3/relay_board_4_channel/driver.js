const { Device } = require('homey');
 'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class relay_board_4_channel extends ZigBeeDriver { } module.exports = relay_board_4_channel; 


