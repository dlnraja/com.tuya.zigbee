const { Device } = require('homey');
'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class doublepowerpoint extends ZigBeeDriver { } module.exports = doublepowerpoint; 


