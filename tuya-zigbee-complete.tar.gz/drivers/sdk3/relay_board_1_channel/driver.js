const { Device } = require('homey');
 'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class relay_board_1_channel extends ZigBeeDriver { } module.exports = relay_board_1_channel; 


