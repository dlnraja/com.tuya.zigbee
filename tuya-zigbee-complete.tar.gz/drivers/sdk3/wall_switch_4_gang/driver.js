const { Device } = require('homey');
 'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class wall_switch_4_gang extends ZigBeeDriver { } module.exports = wall_switch_4_gang; 


