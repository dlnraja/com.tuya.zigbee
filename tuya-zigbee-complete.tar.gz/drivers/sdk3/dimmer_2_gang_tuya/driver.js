const { Device } = require('homey');
'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class dimmer_2_gang_tuya extends ZigBeeDriver { } module.exports = dimmer_2_gang_tuya; 


