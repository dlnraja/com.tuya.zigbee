const { Device } = require('homey');
 'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class switch_2_gang_metering extends ZigBeeDriver { } module.exports = switch_2_gang_metering; 


