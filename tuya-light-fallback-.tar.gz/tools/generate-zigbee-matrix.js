const fs = require('fs'); const path = require('path'); console.log('Zigbee matrix generator starting...');
