const fs = require('fs'); const path = require('path'); console.log('TODO scanner starting...');
