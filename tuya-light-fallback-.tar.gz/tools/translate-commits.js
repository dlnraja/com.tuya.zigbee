console.log('Commit translator ready');
