Universal TUYA Zigbee Device

This app lets you control and integrate all your TUYA Zigbee devices in Homey. Universal, smart, and fully automated. Enjoy advanced automation, real-time documentation, and robust compatibility with Homey SDK3.

Status: In Active Development

For community support and updates, visit the official Homey forum thread:
https://community.homey.app/t/app-community-universal-tuya-zigbee-device/140352

Credits and contributors are listed in the app manifest.
