const { Device } = require('homey');
'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class doublepowerpoint2 extends ZigBeeDriver { } module.exports = doublepowerpoint2; 


