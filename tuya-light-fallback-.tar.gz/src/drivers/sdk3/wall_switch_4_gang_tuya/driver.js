const { Device } = require('homey');
'use strict'; const { ZigBeeDriver } = require("homey-zigbeedriver"); class wall_switch_4_gang_tuya extends ZigBeeDriver { } module.exports = wall_switch_4_gang_tuya; 


