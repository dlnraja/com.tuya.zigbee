const { Device } = require('homey');
'use strict'; const { ZigBeeDriver } = require("homey-zigbeedriver"); class wall_switch_6_gang_tuya extends ZigBeeDriver { } module.exports = wall_switch_6_gang_tuya; 


