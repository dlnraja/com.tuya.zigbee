const { Device } = require('homey');
 'use strict'; const { ZigBeeDriver } = require('homey-meshdriver'); class switch_3_gang extends ZigBeeDriver { } module.exports = switch_3_gang; 


