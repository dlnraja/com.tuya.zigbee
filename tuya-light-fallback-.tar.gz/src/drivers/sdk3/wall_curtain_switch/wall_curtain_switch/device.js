const { Device } = require('homey');
"use strict"; const { ZigBeeDevice } = require("homey-zigbeedriver"); const { Cluster, debug, CLUSTER } = require("zigbee-clusters"); const TuyaWindowCoveringCluster = require("../../lib/TuyaWindowCoveringCluster"); const { mapValueRange } = require('../../lib/util'); Cluster.addCluster(TuyaWindowCoveringCluster); const UP_OPEN = 'upOpen'; const DOWN_CLOSE = 'downClose'; const REPORT_DEBOUNCER = 5000; class wallcurtainswitch extends ZigbeeDevice { invertPercentageLiftValue = false; constructor(...args) { super(...args); this._reportPercentageDebounce = null; this._reportDebounceEnabled = false; } async this.registerCapability('onoff', CLUSTER.ON_OFF); await super. this.registerCapability('onoff', CLUSTER.ON_OFF); zclNode }); this.printNode(); 


