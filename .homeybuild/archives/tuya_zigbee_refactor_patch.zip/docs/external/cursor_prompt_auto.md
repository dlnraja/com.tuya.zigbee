# 🧠 Cursor Auto-Prompt System

## 📋 Instructions pour Cursor

🧠 Cursor must refer to cursor_todo_queue.md before executing or suggesting anything.
This queue persists between crashes and sessions. Treat it as master instruction memory.
Update it at every meaningful step.
