# 📁 Documentation de la Structure

## 📅 Date
**05/08/2025 16:24:34**

## 📂 Dossier Analysé
**D:\Download\fold**

## 📊 Statistiques
- **Fichiers**: 53
- **Dossiers**: 1
- **Taille totale**: 67.31 MB

## 🏗️ Structure
```
📁 fold
  📄 6678652ef6fb4060908f5623ee7062950debc346d770843c281d94147e604e01-2025-07-28-05-05-23-863212661c51411182b67cb394b0fe15.zip (16.51 MB)
  📄 6678652ef6fb4060908f5623ee7062950debc346d770843c281d94147e604e01-2025-07-28-05-05-46-b5a4ad670faf482ea2f43d554f00de76.zip (16.51 MB)
  📄 com.tuya.zigbee-master (1).zip (7.96 MB)
  📄 com.tuya.zigbee-master (2).zip (4.88 MB)
  📄 com.tuya.zigbee-master (3).zip (2.65 MB)
  📄 com.tuya.zigbee-master (4).zip (2.33 MB)
  📄 com.tuya.zigbee-master-corrected.zip (2.28 MB)
  📄 com.tuya.zigbee-master-final.zip (2.56 MB)
  📄 com.tuya.zigbee-master.zip (7.96 MB)
  📄 cursor_global_policy (2).md (2.58 KB)
  📄 cursor_global_policy.md (131 Bytes)
  📄 cursor_init.ps1 (371 Bytes)
  📄 cursor_init.sh (214 Bytes)
  📄 cursor_prompt_auto.md (288 Bytes)
  📄 cursor_prompt_tuya_main.txt (2.95 KB)
  📄 cursor_prompt_tuya_reorg.txt (5.28 KB)
  📄 cursor_recovery_package.zip (1.79 KB)
  📄 cursor_r_capitulatif_des_t_ches_et_avan.md (174.18 KB)
  📄 cursor_todo_queue.md (703 Bytes)
  📄 en comprennant toutes les versions.txt (1.83 KB)
  📄 instruction_cursor_com_tuya_zigbee.txt (4.87 KB)
  📄 mdr.txt (6.39 KB)
  📄 mega promot premier relase .txt (5.03 KB)
  📄 mega_prompt_cursor_tuya.txt (521 Bytes)
  📄 new.txt (5.25 KB)
  📄 pipeline_instructions_extend_appjs.txt (1.6 KB)
  📄 readme.md (2.48 KB)
  📄 README_megaproject_full_multilang.txt (4.41 KB)
  📄 README_SYNTHESIZED_MASTER.md (768 Bytes)
  📄 readme_tuya_zigbee (2).txt (6.45 KB)
  📄 readme_tuya_zigbee.txt (6.23 KB)
  📄 recupere la queue qui a sauté et fa.txt (20.68 KB)
  📄 RestoreAndRebuild.ps1 (3.07 KB)
  📄 tuya_git_extras.zip (1.11 KB)
  📄 tuya_project_extras.zip (1.44 KB)
  📄 tuya_zigbee_cursor_bundle_FINAL (1).tar.gz (392.4 KB)
  📄 tuya_zigbee_cursor_bundle_FINAL.tar.gz (392.4 KB)
  📄 tuya_zigbee_cursor_bundle_final.txt (1.73 MB)
  📄 tuya_zigbee_cursor_bundle_UPDATED.tar.gz (391.77 KB)
  📄 tuya_zigbee_cursor_full_bundle (1).txt (5.74 KB)
  📄 tuya_zigbee_cursor_full_bundle.txt (3.93 KB)
  📄 tuya_zigbee_cursor_rebuild (1).md (4.9 KB)
  📄 tuya_zigbee_cursor_rebuild (2).md (6.07 KB)
  📄 tuya_zigbee_cursor_rebuild (3).md (3.8 KB)
  📄 tuya_zigbee_cursor_rebuild (4).md (4.81 KB)
  📄 tuya_zigbee_cursor_rebuild (5).md (3.23 KB)
  📄 tuya_zigbee_cursor_rebuild (6).md (3.84 KB)
  📄 tuya_zigbee_cursor_rebuild (7).md (2.5 KB)
  📄 tuya_zigbee_cursor_rebuild (8).md (4.11 KB)
  📄 tuya_zigbee_cursor_rebuild.md (4.46 KB)
  📄 ultime.txt (5.1 KB)
  📄 zigbee ref.txt (9.13 KB)
  📄 [APP][PRO]Universal TUYA Zigbee Device App - lite version - Apps - Homey Community Forum.pdf (489.51 KB)

```

---
*Généré automatiquement par ExternalFolderProcessor*
