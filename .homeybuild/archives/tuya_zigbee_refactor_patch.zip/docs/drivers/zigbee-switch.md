# 🔌 zigbee-switch

## 📋 Description

Driver pour appareils ZIGBEE de type switches.

## 🔧 Capacités

- `onoff`

## 📁 Fichier

`drivers/zigbee/zigbee-switch.js`

## 🎯 Utilisation

Ce driver est automatiquement détecté par Homey et peut être utilisé avec les appareils compatibles.

## 🔄 Mises à jour

Généré automatiquement par DriversGeneratorUltimate.
