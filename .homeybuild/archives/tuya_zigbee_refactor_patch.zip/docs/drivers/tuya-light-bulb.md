# 💡 tuya-light-bulb

## 📋 Description

Driver pour appareils TUYA de type lights.

## 🔧 Capacités

- `onoff`
- `dim`
- `light_temperature`
- `light_hue`
- `light_saturation`

## 📁 Fichier

`drivers/tuya/tuya-light-bulb.js`

## 🎯 Utilisation

Ce driver est automatiquement détecté par Homey et peut être utilisé avec les appareils compatibles.

## 🔄 Mises à jour

Généré automatiquement par DriversGeneratorUltimate.
