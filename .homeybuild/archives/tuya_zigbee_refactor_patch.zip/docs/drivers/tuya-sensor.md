# 🌡️ tuya-sensor

## 📋 Description

Driver pour appareils TUYA de type sensors.

## 🔧 Capacités

- `measure_temperature`
- `measure_humidity`
- `measure_pressure`

## 📁 Fichier

`drivers/tuya/tuya-sensor.js`

## 🎯 Utilisation

Ce driver est automatiquement détecté par Homey et peut être utilisé avec les appareils compatibles.

## 🔄 Mises à jour

Généré automatiquement par DriversGeneratorUltimate.
