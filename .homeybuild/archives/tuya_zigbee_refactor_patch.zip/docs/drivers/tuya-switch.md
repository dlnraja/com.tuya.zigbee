# 🔌 tuya-switch

## 📋 Description

Driver pour appareils TUYA de type switches.

## 🔧 Capacités

- `onoff`

## 📁 Fichier

`drivers/tuya/tuya-switch.js`

## 🎯 Utilisation

Ce driver est automatiquement détecté par Homey et peut être utilisé avec les appareils compatibles.

## 🔄 Mises à jour

Généré automatiquement par DriversGeneratorUltimate.
