# 🌡️ zigbee-sensor

## 📋 Description

Driver pour appareils ZIGBEE de type sensors.

## 🔧 Capacités

- `measure_temperature`
- `measure_humidity`

## 📁 Fichier

`drivers/zigbee/zigbee-sensor.js`

## 🎯 Utilisation

Ce driver est automatiquement détecté par Homey et peut être utilisé avec les appareils compatibles.

## 🔄 Mises à jour

Généré automatiquement par DriversGeneratorUltimate.
