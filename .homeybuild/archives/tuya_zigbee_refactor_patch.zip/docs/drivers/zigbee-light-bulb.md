# 💡 zigbee-light-bulb

## 📋 Description

Driver pour appareils ZIGBEE de type lights.

## 🔧 Capacités

- `onoff`
- `dim`
- `light_temperature`

## 📁 Fichier

`drivers/zigbee/zigbee-light-bulb.js`

## 🎯 Utilisation

Ce driver est automatiquement détecté par Homey et peut être utilisé avec les appareils compatibles.

## 🔄 Mises à jour

Généré automatiquement par DriversGeneratorUltimate.
