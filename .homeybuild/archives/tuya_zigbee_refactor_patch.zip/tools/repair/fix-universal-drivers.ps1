# 🔧 CORRECTION DES DRIVERS UNIVERSELS
# =====================================

Write-Host "🔧 CORRECTION DES DRIVERS UNIVERSELS" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan

# Configuration des chemins
$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$driversPath = Join-Path $projectRoot "drivers"
$appJsonPath = Join-Path $projectRoot "app.json"

Write-Host "📁 Répertoire projet: $projectRoot" -ForegroundColor Green
Write-Host "📁 Répertoire drivers: $driversPath" -ForegroundColor Green

# Configuration Zigbee pour chaque type de driver universel
$universalDriverConfigs = @{
    'fan-tuya-universal' = @{
        manufacturerName = '_TZ3000_1h2x4akh'
        productId = 'TS0601'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genPowerCfg', 'genOnOff', 'genLevelCtrl', 'genFanControl')
                    output = @('genBasic', 'genPowerCfg', 'genOnOff', 'genLevelCtrl', 'genFanControl')
                }
                bindings = @('genBasic', 'genPowerCfg', 'genOnOff', 'genLevelCtrl', 'genFanControl')
            }
        }
    }
    'lock-tuya-universal' = @{
        manufacturerName = '_TZ3000_ltiqubue'
        productId = 'TS0601'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genPowerCfg', 'genDoorLock', 'genAlarms', 'genTime')
                    output = @('genBasic', 'genPowerCfg', 'genDoorLock', 'genAlarms', 'genTime')
                }
                bindings = @('genBasic', 'genPowerCfg', 'genDoorLock', 'genAlarms', 'genTime')
            }
        }
    }
    'switch' = @{
        manufacturerName = '_TZ3000_8kzqqzu4'
        productId = 'TS0001'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genOnOff', 'genPowerCfg')
                    output = @('genBasic', 'genOnOff', 'genPowerCfg')
                }
                bindings = @('genBasic', 'genOnOff', 'genPowerCfg')
            }
        }
    }
    'tuya-climate-universal' = @{
        manufacturerName = '_TZ3000_vd43bbfq'
        productId = 'TS0601'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genPowerCfg', 'genTemperatureMeasurement', 'genHumidityMeasurement', 'genThermostat')
                    output = @('genBasic', 'genPowerCfg', 'genTemperatureMeasurement', 'genHumidityMeasurement', 'genThermostat')
                }
                bindings = @('genBasic', 'genPowerCfg', 'genTemperatureMeasurement', 'genHumidityMeasurement', 'genThermostat')
            }
        }
    }
    'tuya-cover-universal' = @{
        manufacturerName = '_TZ3000_4ux0ondb'
        productId = 'TS0602'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genPowerCfg', 'genWindowCovering', 'genTime', 'genAlarms')
                    output = @('genBasic', 'genPowerCfg', 'genWindowCovering', 'genTime', 'genAlarms')
                }
                bindings = @('genBasic', 'genPowerCfg', 'genWindowCovering', 'genTime', 'genAlarms')
            }
        }
    }
    'tuya-light-universal' = @{
        manufacturerName = '_TZ3000_qa8s8vca'
        productId = 'TS0501B'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genPowerCfg', 'genOnOff', 'genLevelCtrl', 'genColorCtrl', 'genScenes')
                    output = @('genBasic', 'genPowerCfg', 'genOnOff', 'genLevelCtrl', 'genColorCtrl', 'genScenes')
                }
                bindings = @('genBasic', 'genPowerCfg', 'genOnOff', 'genLevelCtrl', 'genColorCtrl', 'genScenes')
            }
        }
    }
    'tuya-plug-universal' = @{
        manufacturerName = '_TZ3000_b28wrpvx'
        productId = 'TS011F'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genPowerCfg', 'genOnOff', 'genElectricalMeasurement', 'genMetering')
                    output = @('genBasic', 'genPowerCfg', 'genOnOff', 'genElectricalMeasurement', 'genMetering')
                }
                bindings = @('genBasic', 'genPowerCfg', 'genOnOff', 'genElectricalMeasurement', 'genMetering')
            }
        }
    }
    'tuya-remote-universal' = @{
        manufacturerName = '_TZ3000_8kzqqzu4'
        productId = 'TS0601'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genPowerCfg', 'genScenes')
                    output = @('genBasic', 'genPowerCfg', 'genScenes')
                }
                bindings = @('genBasic', 'genPowerCfg', 'genScenes')
            }
        }
    }
    'tuya-sensor-universal' = @{
        manufacturerName = '_TZ3000_1h2x4akh'
        productId = 'TS0201'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genPowerCfg', 'genTemperatureMeasurement', 'genHumidityMeasurement', 'genOccupancySensing')
                    output = @('genBasic', 'genPowerCfg', 'genTemperatureMeasurement', 'genHumidityMeasurement', 'genOccupancySensing')
                }
                bindings = @('genBasic', 'genPowerCfg', 'genTemperatureMeasurement', 'genHumidityMeasurement', 'genOccupancySensing')
            }
        }
    }
    'zigbee-tuya-universal' = @{
        manufacturerName = '_TZ3000_generic'
        productId = 'TS0601'
        endpoints = @{
            "1" = @{
                clusters = @{
                    input = @('genBasic', 'genPowerCfg', 'genOnOff')
                    output = @('genBasic', 'genPowerCfg', 'genOnOff')
                }
                bindings = @('genBasic', 'genPowerCfg', 'genOnOff')
            }
        }
    }
}

# Étape 1: Corriger app.json - platforms doit être un array
Write-Host "`n🔧 ÉTAPE 1: Correction de app.json..." -ForegroundColor Magenta

if (Test-Path $appJsonPath) {
    try {
        $appContent = Get-Content $appJsonPath -Raw
        $appConfig = $appContent | ConvertFrom-Json
        
        # Corriger platforms pour être un array
        if ($appConfig.platforms -ne 'local') {
            $appConfig.platforms = @('local')
            $appConfig | ConvertTo-Json -Depth 10 | Set-Content -Path $appJsonPath -Encoding UTF8
            Write-Host "✅ app.json corrigé: platforms = ['local']" -ForegroundColor Green
        } else {
            Write-Host "✅ app.json déjà correct" -ForegroundColor Green
        }
    } catch {
        Write-Host "❌ Erreur lors de la correction de app.json: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Étape 2: Corriger tous les drivers universels
Write-Host "`n🔧 ÉTAPE 2: Correction des drivers universels..." -ForegroundColor Magenta

$correctedCount = 0

foreach ($driverName in $universalDriverConfigs.Keys) {
    $driverPath = Join-Path $driversPath $driverName
    $composePath = Join-Path $driverPath "driver.compose.json"
    
    if (Test-Path $composePath) {
        try {
            $content = Get-Content $composePath -Raw
            $driverConfig = $content | ConvertFrom-Json
            
            # Vérifier si le driver a besoin de correction
            if (-not $driverConfig.zigbee -or -not $driverConfig.zigbee.manufacturerName) {
                Write-Host "🔧 Correction de $driverName..." -ForegroundColor Yellow
                
                # Ajouter ou corriger la configuration zigbee
                $driverConfig.zigbee = $universalDriverConfigs[$driverName]
                
                # Sauvegarder le driver corrigé
                $updatedContent = $driverConfig | ConvertTo-Json -Depth 10
                Set-Content -Path $composePath -Value $updatedContent -Encoding UTF8
                
                $correctedCount++
                $config = $universalDriverConfigs[$driverName]
                Write-Host "✅ $driverName corrigé avec $($config.manufacturerName)/$($config.productId)" -ForegroundColor Green
            } else {
                Write-Host "✅ $driverName déjà correct" -ForegroundColor Green
            }
        } catch {
            Write-Host "❌ Erreur lors de la correction de $driverName : $($_.Exception.Message)" -ForegroundColor Red
        }
    } else {
        Write-Host "⚠️  Driver $driverName non trouvé" -ForegroundColor Yellow
    }
}

Write-Host "`n🎯 $correctedCount drivers corrigés" -ForegroundColor Green

# Étape 3: Vérification finale
Write-Host "`n🔍 ÉTAPE 3: Vérification finale..." -ForegroundColor Magenta

$finalDrivers = Get-ChildItem -Path $driversPath -Directory | Select-Object -ExpandProperty Name
$validCount = 0
$totalCount = 0

foreach ($driverDir in $finalDrivers) {
    $composePath = Join-Path $driversPath $driverDir "driver.compose.json"
    
    if (Test-Path $composePath) {
        $totalCount++
        try {
            $content = Get-Content $composePath -Raw
            $driverConfig = $content | ConvertFrom-Json
            
            if ($driverConfig.zigbee -and 
                $driverConfig.zigbee.manufacturerName -and 
                $driverConfig.zigbee.productId -and 
                $driverConfig.zigbee.endpoints) {
                $validCount++
            }
        } catch {
            Write-Host "⚠️  Erreur lors de la vérification de $driverDir" -ForegroundColor Red
        }
    }
}

$validationRate = if ($totalCount -gt 0) { [math]::Round(($validCount / $totalCount) * 100) } else { 0 }

Write-Host "📊 Vérification finale:" -ForegroundColor Yellow
Write-Host "   - Total drivers: $totalCount" -ForegroundColor White
Write-Host "   - Drivers valides: $validCount" -ForegroundColor White
Write-Host "   - Taux de validation: $validationRate%" -ForegroundColor White

Write-Host "`n🎉 CORRECTION TERMINÉE !" -ForegroundColor Cyan
Write-Host "🚀 Prêt pour homey app validate" -ForegroundColor Green
