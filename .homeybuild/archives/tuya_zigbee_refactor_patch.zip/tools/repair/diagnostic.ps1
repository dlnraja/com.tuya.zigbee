# 🔍 DIAGNOSTIC SIMPLE
# =====================

Write-Host "🔍 DIAGNOSTIC SIMPLE" -ForegroundColor Cyan
Write-Host "=====================" -ForegroundColor Cyan

# Configuration des chemins
$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$driversPath = Join-Path $projectRoot "drivers"
$appJsonPath = Join-Path $projectRoot "app.json"

Write-Host "📁 Répertoire projet: $projectRoot" -ForegroundColor Green
Write-Host "📁 Répertoire drivers: $driversPath" -ForegroundColor Green

# Vérifier app.json
Write-Host "`n🔍 Vérification de app.json..." -ForegroundColor Yellow

if (Test-Path $appJsonPath) {
    try {
        $appContent = Get-Content $appJsonPath -Raw
        $appConfig = $appContent | ConvertFrom-Json
        
        Write-Host "✅ app.json trouvé" -ForegroundColor Green
        Write-Host "   - ID: $($appConfig.id)" -ForegroundColor White
        Write-Host "   - Platforms: $($appConfig.platforms)" -ForegroundColor White
        Write-Host "   - Nombre de drivers: $($appConfig.drivers.Count)" -ForegroundColor White
        
        # Vérifier le premier driver pour la structure Zigbee
        if ($appConfig.drivers.Count -gt 0) {
            $firstDriver = $appConfig.drivers[0]
            Write-Host "`n🔍 Premier driver analysé: $($firstDriver.id)" -ForegroundColor Yellow
            
            if ($firstDriver.zigbee) {
                Write-Host "   ✅ Configuration Zigbee trouvée:" -ForegroundColor Green
                Write-Host "      - manufacturerName: $($firstDriver.zigbee.manufacturerName)" -ForegroundColor White
                Write-Host "      - productId: $($firstDriver.zigbee.productId)" -ForegroundColor White
                Write-Host "      - endpoints: $($firstDriver.zigbee.endpoints.Count) endpoint(s)" -ForegroundColor White
            } else {
                Write-Host "   ❌ Configuration Zigbee manquante" -ForegroundColor Red
            }
        }
        
    } catch {
        Write-Host "❌ Erreur lors de la lecture de app.json: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "❌ app.json non trouvé" -ForegroundColor Red
}

# Vérifier les drivers
Write-Host "`n🔍 Vérification des drivers..." -ForegroundColor Yellow

$driverDirs = Get-ChildItem -Path $driversPath -Directory | Select-Object -ExpandProperty Name
Write-Host "📊 Trouvé $($driverDirs.Count) dossiers de drivers" -ForegroundColor White

foreach ($driverDir in $driverDirs) {
    $composePath = Join-Path $driversPath $driverDir "driver.compose.json"
    
    if (Test-Path $composePath) {
        try {
            $content = Get-Content $composePath -Raw
            $driverConfig = $content | ConvertFrom-Json
            
            if ($driverConfig.zigbee) {
                Write-Host "   ✅ $driverDir : Zigbee configuré" -ForegroundColor Green
            } else {
                Write-Host "   ❌ $driverDir : Zigbee manquant" -ForegroundColor Red
            }
        } catch {
            Write-Host "   ⚠️  $driverDir : Erreur de lecture" -ForegroundColor Yellow
        }
    } else {
        Write-Host "   ⚠️  $driverDir : driver.compose.json manquant" -ForegroundColor Yellow
    }
}

Write-Host "`n🎉 Diagnostic terminé !" -ForegroundColor Cyan
