// Contenu de base pour validate_compose.mjs

import fs from 'fs';
import path from 'path';

const DRIVERS_DIR = '.homeycompose/drivers';

function validateCompose() {
  const errors = [];
  
  if (!fs.existsSync(DRIVERS_DIR)) {
    console.error(`❌ Drivers directory not found: ${DRIVERS_DIR}`);
    process.exit(1);
  }
  
  const driverDirs = fs.readdirSync(DRIVERS_DIR, { withFileTypes: true })
    .filter(dirent => dirent.isDirectory() && dirent.name !== 'templates') // Exclude templates
    .map(dirent => dirent.name);

  driverDirs.forEach(driverId => {
    const composePath = path.join(DRIVERS_DIR, driverId, 'driver.compose.json');
    
    if (!fs.existsSync(composePath)) {
      errors.push(`❌ Missing driver.compose.json for driver: ${driverId}`);
      return;
    }
    
    try {
      const compose = JSON.parse(fs.readFileSync(composePath, 'utf8'));
      
      // Validate ID matches directory name
      if (compose.id !== driverId) {
        errors.push(`❌ ID mismatch: ${compose.id} should be ${driverId}`);
      }
      
      // Validate required fields
      if (!compose.class) errors.push(`❌ Missing class for driver: ${driverId}`);
      if (!compose.capabilities || compose.capabilities.length === 0) {
        errors.push(`❌ Missing capabilities for driver: ${driverId}`);
      }
      
      // Validate icon exists
      const iconPath = path.join(DRIVERS_DIR, driverId, 'assets', 'icon.svg');
      if (!fs.existsSync(iconPath)) {
        errors.push(`❌ Missing icon.svg for driver: ${driverId}`);
      }
      
    } catch (e) {
      errors.push(`❌ Invalid JSON in ${composePath}: ${e.message}`);
    }
  });
  
  if (errors.length > 0) {
    console.error('\nValidation errors:\n');
    errors.forEach(err => console.error(err));
    console.error('\n❌ Validation failed');
    process.exit(1);
  }
  
  console.log('✅ All driver.compose.json files are valid');
}

validateCompose();
