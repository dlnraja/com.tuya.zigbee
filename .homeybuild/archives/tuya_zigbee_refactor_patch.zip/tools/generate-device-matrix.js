console.log("📊 DEVICE MATRIX GENERATOR"); console.log("✅ Script créé avec succès !");
