// ✅ Cursor-Aware Script
// Description: Génère un changelog à partir des commits Git et des fichiers modifiés

const { execSync } = require('child_process');

try {
    const log = execSync('git log --pretty=format:"- %ad: %s" --date=short', { encoding: 'utf8' });
    require('fs').writeFileSync('CHANGELOG.md', '# 📜 Changelog\n\n' + log);
    console.log('✅ Changelog généré avec succès.');
} catch (e) {
    console.error('❌ Erreur lors de la génération du changelog :', e);
}
