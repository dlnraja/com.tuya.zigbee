// ✅ Cursor-Aware Script
// Description: Vérifie tous les fichiers drivers Homey pour Tuya Zigbee
// Requires: Node.js >= 18

const fs = require('fs');
const path = require('path');

const driversDir = './drivers';

function isValidDriver(filePath) {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        const json = JSON.parse(data);
        return json.id && json.zigbee && json.endpoints;
    } catch (err) {
        return false;
    }
}

fs.readdirSync(driversDir).forEach(file => {
    const fullPath = path.join(driversDir, file);
    if (file.endsWith('.driver.compose.json')) {
        const valid = isValidDriver(fullPath);
        console.log(`${file}: ${valid ? '✅ VALIDE' : '❌ INVALIDE'}`);
    }
});
