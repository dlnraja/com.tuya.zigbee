#!/bin/bash
# ✅ Cursor-Aware Script
# Description: Génére la version tuya-light sans IA ni automatisation

set -e

echo "📦 Génération de tuya-light..."
mkdir -p tuya-light/drivers

cp -r drivers/*.driver.compose.json tuya-light/drivers/
cp README.md tuya-light/README.md
sed -i '/IA/d;/automation/d;/intelligence artificielle/d' tuya-light/README.md

echo "✅ Version lite générée dans tuya-light/"
