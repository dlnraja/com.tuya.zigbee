#!/bin/bash
# Script Bash pour relancer Cursor proprement
echo "🚀 Initialisation Cursor pour projet Tuya Zigbee"
if [ -f "cursor_todo_queue.md" ]; then echo "📋 Queue trouvée, reprise des tâches..."; fi
